package ma.enset.userservice.enums;

public enum Role {
    ADMIN,
    DOCTORANT,       // Celui qui est accepté
    DIRECTEUR_THESE,
    CANDIDAT         // NOUVEAU : Celui qui vient de s'inscrire
}
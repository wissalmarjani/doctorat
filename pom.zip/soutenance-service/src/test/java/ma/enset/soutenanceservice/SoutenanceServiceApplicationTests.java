package ma.enset.soutenanceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoutenanceServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}

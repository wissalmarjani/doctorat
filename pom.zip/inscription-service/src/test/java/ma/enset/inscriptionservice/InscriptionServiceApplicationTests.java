package ma.enset.inscriptionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InscriptionServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}

package ma.enset.inscriptionservice.enums;

public enum TypeDocument {
    DIPLOME,
    CV,
    LETTRE_MOTIVATION,
    ATTESTATION_TRAVAIL,
    AUTRE
}
package ma.enset.inscriptionservice.enums;

public enum TypeInscription {
    PREMIERE_INSCRIPTION,  // 1ère année
    REINSCRIPTION          // Années suivantes
}
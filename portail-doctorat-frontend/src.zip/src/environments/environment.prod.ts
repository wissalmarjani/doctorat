export const environment = {
  production: true,
  apiUrl: '/api',  // Relatif en production
  
  userServiceUrl: '/api',
  inscriptionServiceUrl: '/api',
  soutenanceServiceUrl: '/api',
  notificationServiceUrl: '/api',
  documentServiceUrl: '/api'
};

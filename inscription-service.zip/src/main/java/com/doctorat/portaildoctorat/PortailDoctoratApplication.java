package com.doctorat.portaildoctorat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortailDoctoratApplication {

    public static void main(String[] args) {
        SpringApplication.run(PortailDoctoratApplication.class, args);
    }

}

package com.doctorat.portaildoctorat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortailDoctoratApplicationTests {

    @Test
    void contextLoads() {
    }

}
